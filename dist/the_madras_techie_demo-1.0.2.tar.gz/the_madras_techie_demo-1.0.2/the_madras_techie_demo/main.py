def hello():
    print("Hi from Madras Techie")

def height():
    print("We are all tall")    

def weight():
    print("We are all weight")

def location():
    print("We are worldly beings")    

def job():
    print("We work on the best possible works suitable for us")

def sports():
    print("We play our best suitable sports")    