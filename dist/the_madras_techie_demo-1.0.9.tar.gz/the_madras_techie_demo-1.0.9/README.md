
# Demo - The Madras Techie

This is a good application to know more about an organization.
We can use this kind of template and perform a lot of things.